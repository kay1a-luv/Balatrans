return {
    v_dictionary = {
        a_mult = "+%s Mult"
    },
    descriptions = {
        Joker = {
            aromantic_pride = {
                name = "Aromantic Pride",
                text = {
                    "Gains {C:mult}+12{} Mult when",
                    "a {C:tarot}World{} card is used",
                    "{C:inactive}(Currently {C:mult}+#1#{C:inactive} Mult)"
                }
            }
            asexual_pride = {
                name = "Asexual Pride",
                text = {
                    "Gains {C:mult}+12{} Mult when",
                    "a {C:tarot}Sun{} card is used",
                    "{C:inactive}(Currently {C:mult}+#1#{C:inactive} Mult)"
                }
            },
            demiromantic_pride = {
                name = "Demiromantic Pride",
                text = {
                    "Gains {C:mult}+12{} Mult when",
                    "a {C:tarot}Star{} card is used",
                    "{C:inactive}(Currently {C:mult}+#1#{C:inactive} Mult)"
                }
            },
            graysexual_pride = {
                name = "Graysexual Pride",
                text = {
                    "Gains {C:mult}+12{} Mult when",
                    "a {C:tarot}Moon{} card is used",
                    "{C:inactive}(Currently {C:mult}+#1#{C:inactive} Mult)"
                }
            }
            bisexual_pride = {
                name = "Bisexual Pride",
                text = {
                    "Gains {C:mult}+2{} Mult per hand",
                    "containing a {C:attention}face card{}",
                    "{C:inactive}(Currently {C:mult}+#1#{C:inactive} Mult)"
                }
            }
            blahaj = {
                name = "Blahaj",
                text = {
                    "{X:mult,C:white}X#1#{} Mult",
                    "After defeating blind, gain {C:mult}+0.03{}",
                    "per unplayed card, consumable,",
                    "and other Joker {C:inactive}(#2# total)"
                }
            }
        }
    }
}


